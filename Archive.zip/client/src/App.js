import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Quagga from 'quagga'; // ES6


class App extends Component {

  render() {
    return (
      <>
        Barcode Scanner

      </>
    );
  }
}

export default App;
